#include "stdafx.h"
#include "Personnage.h"
#include <iostream>
#include <string>
#define affiche(x) std::cout<<x<<std::endl
#define espace() std::cout<<" "<<std::endl
using namespace std;

// initialiser les attributs
Personnage::Personnage() : a_vie(100), a_mana(100), a_arme(Arme()) // define the skills 
{

}

Personnage::Personnage(std::string nomArme, int degatArme) : a_vie(100), a_mana(100), a_arme( nomArme, degatArme)
{

}

Personnage::~Personnage()
{

}

std::string Personnage::nomPerso(std::string nom)
{
	a_nom = nom;
	return a_nom;
}

std::string Personnage::getNom() const
{
	return a_nom;
}

void Personnage::afficherEtat() const
{
	affiche("Vie: " << a_vie);
	affiche("Mana: " << a_mana);
	a_arme.afficher();
	if (a_vie == 0)
	{
		affiche("Mort par k.o !");
	}
	espace();
}

void Personnage::manaAttack(int mana) // each attack the mana is use
{
	a_mana -= mana;
	if (a_mana < 0)
	{
		a_mana = 0;
	}
}

void Personnage::recoveryMana()
{
	int recover = 15;
	a_mana += recover;

	if (a_mana > 100)
	{
		a_mana = 100;
	}
}


void Personnage::recevoirDegat(int nbre_Vie_perdu)
{
	a_vie -= nbre_Vie_perdu;

	if (a_vie < 0) // pour pas que la vie soit n�gative
	{
		a_vie = 0;
	}

}



void Personnage::attaqueSimple(Personnage &cible)
{
	
	affiche( getNom() <<" attaque avec son " << a_arme.nomDeLarme() << ", et inflige " << a_arme.getDegat() << " a son adversaire");
	espace();
	cible.recevoirDegat(a_arme.getDegat());
}

void Personnage::superattack(Personnage &cible)
{

	affiche(getNom() << " fait une super attack " << a_arme.nomDeLarme() << ", et inflige " << a_arme.getDegat() << " a son adversiare");
	espace();
	cible.recevoirDegat(a_arme.getDegat());
	manaAttack(25);
}


void Personnage::boirePotion(int quantitepotion)
{
	a_vie += quantitepotion;

	if (a_vie > 100)
	{
		a_vie = 100;
	}
	affiche( getNom() <<" mange un senzu et recupere " << quantitepotion << " points de vie");
	espace();
}

int Personnage::persoVie()  // for get yhe life of the character
{
	return a_vie;
}


void Personnage::changerArme(std::string nom_NouvelleArme, int degat_NouvelleArme) // For change weapon
{
	a_arme.changer(nom_NouvelleArme, degat_NouvelleArme);
}


bool Personnage::estVivant() const
{
	return a_vie > 0;
}
