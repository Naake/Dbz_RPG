#pragma once
#include "stdafx.h"
#ifndef DEF_ARME
#define DEF_ARME
#include <string>



class Arme {
	
	// Les methodes
public:

	Arme(); // Constructeur , pouvoir initialiser les attributs
	Arme(std::string nom, int degat);
	~Arme();
	void changer(std::string nom, int degat);
	void afficher() const;
	int getDegat() const;
	std::string nomDeLarme() const;

	// Les attributs
private:
	
	std::string a_nom;
	int a_degat;
};


#endif