#pragma once
#include "stdafx.h"
#ifndef DEF_PERSONNAGE
#define DEF_PERSONNAGE
#include <string>
#include "Arme.h"


class Personnage 
{
	// The method
	public:

		Personnage(); //Constructor

		Personnage(std::string nomArme, int degatArme); // definir arme de debut

		~Personnage(); //Destructor

		void afficherEtat() const;

		void attaqueSimple(Personnage &cible); // attaque de base

		void superattack(Personnage &cible); // super attack 


		void boirePotion(int quantitepotion);

		int persoVie();


		void recevoirDegat(int nbre_Vie_perdu);

		void manaAttack(int mana);

		void recoveryMana(); // Afi


		void changerArme(std::string nom_NouvelleArme, int degat_NouvelleArme);

		std::string nomPerso(std::string nom);
	
		std::string getNom() const;

		bool estVivant() const;
	

	// The skills
	private:

		int a_vie;
		int a_mana;
		Arme a_arme; // a_arme is into the object of personnage
		std::string a_nom;

};

#endif // !DEF_PERSONNAGE