#include "stdafx.h"
#include <iostream>
#include <string>
#include "Header.h"



int chiffreHasard()
{
	int chiffre;
	unsigned int srand(time(nullptr)); // fonction initialise fonction aleatoire
	chiffre = rand() %  50;
	return chiffre;
}