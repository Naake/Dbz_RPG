#pragma once
#include "stdafx.h"
#include <iostream>
#include <string>
#include <time.h>

int chiffreHasard();