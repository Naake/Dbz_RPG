#include "stdafx.h"
#include "Arme.h"
#include <iostream>
#include <string>


using namespace std;

Arme::Arme() : a_nom("coup de poing"), a_degat(10)
{

}

Arme::Arme(std::string nom, int degat) : a_nom(nom), a_degat(degat)
{

}

Arme::~Arme()
{

}

void Arme::changer(std::string nom, int degat)
{
	a_nom = nom;
	a_degat = degat;

}

void Arme::afficher() const
{
	std::cout << "votre arme est " << a_nom << ", elle afflige " << a_degat << " de degat a votre adversaire " << std::endl;
}

std::string Arme::nomDeLarme() const
{
	return a_nom;
}

int Arme::getDegat() const
{
	return a_degat;
}




